
package tn.esprit.controller;

import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;


import javafx.event.ActionEvent;
import javafx.scene.control.Button;

import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert;

import javafx.stage.Stage;
import tn.esprit.services.reclamationService;
import tn.esprit.entities.reclamation;
        import java.net.URL;

import java.util.ResourceBundle;


import java.io.IOException;
import java.sql.SQLException;

public class Ajouterreclamation {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;


    @FXML
    private Button ajouterreclamation;

    @FXML
    private TextField descTextfeild;

    @FXML
    private DatePicker datepicker;

    @FXML
    private ChoiceBox<String> typeadd;


    private final reclamationService rs = new reclamationService();

   /*public static boolean validateNotEmpty(TextField... fields) {
        for (TextField field : fields) {
            // Vérifier si le champ est vide ou null
            if (field.getText() == null || field.getText().isEmpty()) {
                return false;
            }
        }
        return true; // Tous les champs ne sont pas vides
    }*/

    @FXML
    void handelajouterButon(ActionEvent event) throws IOException {
        reclamation reclamation = new reclamation(descTextfeild.getText(),  typeadd.getValue(), datepicker.getValue());
        reclamationService reclamationService = new reclamationService();
        try {
            reclamationService.add(reclamation);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText("reclamation ajoutee ");
        alert.show();

        Parent root = FXMLLoader.load(getClass().getResource("/showrecetud.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();




        /*if (validateNotEmpty(descTextfeild)) {
            System.out.println("veuiller remplir la description pour ajouter la reclamation");
        } else {
            System.out.println("veuiller remplir la description pour ajouter la reclamation");
        }*/






    }

   /* public static boolean validateFields(TextField fields) {

        return fields.getText() !=null && !fields.getText().trim().isEmpty(); // Tous les champs sont valides
    }*/



    @FXML
    void initialize() {
        typeadd.getItems().add("cours");
        typeadd.getItems().add("prof");
        typeadd.getItems().add("etudiant");

    }




    }





