package tn.esprit.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import tn.esprit.services.reclamationService;
import tn.esprit.entities.reclamation;


public class Showrecetud {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableView<reclamation> showreclamation;

    @FXML
    private TableColumn<?, ?> desccolone;

    @FXML
    private TableColumn<?, ?> typecolone;

    @FXML
    private TableColumn<?, ?> datecolone;

    @FXML
    private Button ajouterrec;

    @FXML
    private Button modreclamation;

    @FXML
    private Button suppreclamation;


        @FXML
        private void handleTableClick(MouseEvent event) {

            // Vérifier si l'événement est un double clic et si la souris est sur le TableView
            if (event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() == 2 && event.getTarget() instanceof TableRow) {
                // Récupérer la ligne sur laquelle l'utilisateur a cliqué
                TableRow<reclamation> row = (TableRow<reclamation>) event.getTarget();
                reclamation selectedElement = row.getItem();

                if (selectedElement != null) {
                    // Afficher une boîte de dialogue de confirmation pour la modification ou la suppression
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Confirmation");
                    alert.setHeaderText(null);
                    alert.setContentText("Voulez-vous modifier ou supprimer l'élément sélectionné?");

                    // Ajouter les boutons "Modifier" et "Supprimer"
                    ButtonType buttonTypeModify = new ButtonType("Modifier");
                    ButtonType buttonTypeDelete = new ButtonType("Supprimer");
                    ButtonType buttonTypeCancel = new ButtonType("Annuler", ButtonBar.ButtonData.CANCEL_CLOSE);
                    alert.getButtonTypes().setAll(buttonTypeModify, buttonTypeDelete, buttonTypeCancel);

                    // Attendre la réponse de l'utilisateur
                    Optional<ButtonType> result = alert.showAndWait();
                    if (result.isPresent()) {
                        if (result.get() == buttonTypeModify) {
                            // L'utilisateur a choisi de modifier l'élément
                            // Ajoutez votre logique de modification ici
                        } else if (result.get() == buttonTypeDelete) {
                            // L'utilisateur a choisi de supprimer l'élément
                            // Ajoutez votre logique de suppression ici
                        } else {
                            // L'utilisateur a choisi d'annuler
                        }
                    }
                }
            }
        }



    @FXML
    void handleDeleteButton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/deleterelamation.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();

        if (showConfirmationAlert("Voulez-vous vraiment modifier cet élément?")) {
            // Logique de modification ici
            System.out.println("Modification confirmée.");
        } else {
            // L'utilisateur a choisi "Non", ne rien faire
            System.out.println("Modification annulée.");
        }
    }


    public boolean showConfirmationAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText(null);
        alert.setContentText(message);

        // Définir les boutons "Oui" et "Non"
        ButtonType buttonTypeYes = new ButtonType("Oui");
        ButtonType buttonTypeNo = new ButtonType("Non");

        // Ajouter les boutons à la boîte de dialogue
        alert.getButtonTypes().setAll(buttonTypeYes, buttonTypeNo);

        // Afficher la boîte de dialogue et attendre la réponse de l'utilisateur
        alert.showAndWait();

        // Retourner vrai si l'utilisateur a cliqué sur "Oui", faux sinon
        return alert.getResult() == buttonTypeYes;
    }



        @FXML
        void handleUpdateButton (ActionEvent event) throws IOException {

            Parent root = FXMLLoader.load(getClass().getResource("/modifreclamation.fxml"));
            Scene scene = new Scene(root);

            // Obtenir la fenêtre actuelle
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Changer la scène pour afficher la deuxième interface
            stage.setScene(scene);
            stage.show();


            if (showConfirmationAlert("Voulez-vous vraiment modifier cet élément?")) {
                // Logique de modification ici
                System.out.println("Modification confirmée.");
            } else {
                // L'utilisateur a choisi "Non", ne rien faire
                System.out.println("Modification annulée.");
            }
        }


    @FXML
    void handleajouterButton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/ajouterreclamation.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void initialize() {
        final reclamationService rs = new reclamationService();
        try {
            List<reclamation> reclamations = rs.displayList();
            ObservableList<reclamation> observableList = FXCollections.observableList(reclamations);
            showreclamation.setItems(observableList);

            desccolone.setCellValueFactory(new PropertyValueFactory<>("description"));
            typecolone.setCellValueFactory(new PropertyValueFactory<>("type"));
            datecolone.setCellValueFactory(new PropertyValueFactory<>("date"));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }
}

