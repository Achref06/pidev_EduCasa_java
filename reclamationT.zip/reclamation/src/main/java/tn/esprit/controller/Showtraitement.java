package tn.esprit.controller;


import javafx.scene.control.*;
import tn.esprit.entities.reclamation;
import tn.esprit.entities.traitement;
import tn.esprit.services.reclamationService;
import tn.esprit.services.traitementServices;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class Showtraitement {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableView<traitement> showtraitement;

    @FXML
    private TableColumn<?, ?> numRcolone;

    @FXML
    private TableColumn<?, ?> idTcolone;

    @FXML
    private TableColumn<?, ?> reponsecolone;

    @FXML
    private Button ajoutraitement;

    @FXML
    private Button modifiertraitement;

    @FXML
    private Button supptraitement;

    private traitementServices ts;
    private List<traitement> traitements;

    @FXML
    void initialize() throws SQLException {
        final traitementServices ts = new traitementServices();
        try {
            List<traitement> traitements=ts.displayList();
            ObservableList<traitement> observableList= FXCollections.observableList(traitements);
            showtraitement.setItems(observableList);

            idTcolone.setCellValueFactory(new PropertyValueFactory<>("idT"));
            numRcolone.setCellValueFactory(new PropertyValueFactory<>("numR"));
            reponsecolone.setCellValueFactory(new PropertyValueFactory<>("reponse"));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


        /*final traitementServices fs=new traitementServices();
        List<traitement> forms= ts.displayList();
        List<traitement> traitements;
        ObservableList<traitement> observableList= FXCollections.observableList(traitements);
        showtraitement.setItems(observableList);
        numRcolone.setCellValueFactory(new PropertyValueFactory<>("numR"));
        idTcolone.setCellValueFactory(new PropertyValueFactory<>("idT"));
        reponsecolone.setCellValueFactory(new PropertyValueFactory<>("reponse"));
        showtraitement.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                traitement selectedtrait = showtraitement.getSelectionModel().getSelectedItem();

                int selectedId = selectedtrait.getIdT();
                int selectedtraitNumR = selectedtrait.getNumR();
                String selectedreponse = selectedtrait.getReponse();


            }*/

    }

    @FXML
    void handledeleteButton(ActionEvent event) throws Exception{

        // changerInterface (ActionEvent event) throws Exception {
        // Charger la deuxième interface à partir du fichier FXML
        Parent root = FXMLLoader.load(getClass().getResource("/deletetraitment.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();
    }


    @FXML
    void handelmodiftraitbuton(ActionEvent event) throws Exception{
        /*traitement selecttrat = showtraitement.getSelectionModel().getSelectedItem();

        if (selecttrat != null) {
        // Show a confirmation alert before proceeding with modification
        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmationAlert.setContentText("Voulez-vous vraiment modifier ce formulaire ?");

        // Show the confirmation dialog and wait for the user's response
        Optional<ButtonType> result = confirmationAlert.showAndWait();

        // Supposons que 'desccolone' est une TableColumn dans votre TableView

// Pour accéder à la valeur d'une cellule dans cette colonne, vous devez utiliser une cellule
        idTcolone.setCellValueFactory(new PropertyValueFactory<>("nomDeLaPropriété"));
        // Check if the user clicked the "OK" button
        if (result.isPresent() && result.get() == ButtonType.OK) {
            // If the user clicked "OK", proceed with modifying the form
            selecttrat.setidT(idTcolone.getText());
            selecttrat.setType(numRcolone.getText());
            selecttrat.(numRcolone.getText());

            //selectrec.setDate(datecolone.getCellFactory());


            //  selectrec.setDate(selectedItem.getDatecolone());

            // Refresh the table view to reflect the changes
            showreclamation.refresh();

            // Update the form in the database
            reclamationService rs = new reclamationService();
            try {
                rs.update(r);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

            // Show a success message
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Formulaire a été modifié avec succès");
            alert.show();
        }
    } else {
        // If no form is selected, show a warning message
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setContentText("Veuillez sélectionner un formulaire à modifier.");
        alert.show();
    }*/
        // changerInterface (ActionEvent event) throws Exception {
        // Charger la deuxième interface à partir du fichier FXML
        Parent root = FXMLLoader.load(getClass().getResource("/modifiertraitement.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void handletraiterButton(ActionEvent event) throws Exception {

        // changerInterface (ActionEvent event) throws Exception {
        // Charger la deuxième interface à partir du fichier FXML
        Parent root = FXMLLoader.load(getClass().getResource("/ajoutertraitement.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();
    }


}
