package tn.esprit.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.scene.control.*;
import tn.esprit.entities.traitement;
import tn.esprit.services.traitementServices;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;


import javafx.scene.control.cell.PropertyValueFactory;

import javafx.stage.Stage;
import tn.esprit.entities.reclamation;
import tn.esprit.services.reclamationService;

public class Showrecprof {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;


    @FXML
    private Button traiterrec;

    @FXML
    private Button modreclamation;

    @FXML
    private Button suppreclamation;


    /*  @FXML
      private Button addButton;*/
    @FXML
    private TableView<reclamation> showreclamation;

    @FXML
    private TableColumn<?, ?> desccolone;

    @FXML
    private TableColumn<?, ?> typecolone;

    @FXML
    private TableColumn<?, ?> datecolone;

    @FXML
    private ListView<reclamation> reclamationListView;
    private tn.esprit.services.reclamationService rs;
    private List<tn.esprit.entities.reclamation> reclamations = new ArrayList<>();
    private String title;
    private Object String;
    private java.lang.String content;
    private tn.esprit.entities.reclamation reclamation;
    private traitementServices ts;
    private tn.esprit.entities.traitement traitement;


    /*@FXML
    private void handleTableRowClick(MouseEvent event) throws IOException {

        // Vérifier si l'événement est un double clic et si la souris est sur le TableView
        if (event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() == 2 && event.getTarget() instanceof TableRow) {
            // Récupérer la ligne sur laquelle l'utilisateur a cliqué
            TableRow<reclamation> row = (TableRow<reclamation>) event.getTarget();
            reclamation selectedElement = row.getItem();

            if (selectedElement != null) {
                // Afficher une boîte de dialogue de confirmation pour la modification ou la suppression
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation");
                alert.setHeaderText(null);
                alert.setContentText("Voulez-vous traiter ou supprimer l'élément sélectionné?");

                // Ajouter les boutons "Modifier" et "Supprimer"
                ButtonType buttonTypetraiter = new ButtonType("traiter");
                ButtonType buttonTypeDelete = new ButtonType("Supprimer");
                ButtonType buttonTypeCancel = new ButtonType("Annuler", ButtonBar.ButtonData.CANCEL_CLOSE);
                alert.getButtonTypes().setAll(buttonTypetraiter, buttonTypeDelete, buttonTypeCancel);

                // Attendre la réponse de l'utilisateur
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent()) {
                    if (result.get() == buttonTypetraiter) {
                        // L'utilisateur a choisi de modifier l'élément
                        Parent root = FXMLLoader.load(getClass().getResource("/showtraitement.fxml"));
                        Scene scene = new Scene(root);

                        // Obtenir la fenêtre actuelle
                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

                        // Changer la scène pour afficher la deuxième interface
                        stage.setScene(scene);
                        stage.show();

                        }
                    } else if (result.get() == buttonTypeDelete) {
                    Parent root = FXMLLoader.load(getClass().getResource("/deleterelamation.fxml"));
                    Scene scene = new Scene(root);

                    // Obtenir la fenêtre actuelle
                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

                    // Changer la scène pour afficher la deuxième interface
                    stage.setScene(scene);
                    stage.show();

                    if (showConfirmationAlert("Voulez-vous vraiment supprimer cet élément?")) {
                        // Logique de suppression ici
                        System.out.println("Suppression confirmée.");
                    } else {
                        // L'utilisateur a choisi "Non", ne rien faire
                        System.out.println("Suppression annulée.");


                    }
                    } else {
                        // L'utilisateur a choisi d'annuler
                    }
                }
            }
        }*/


    @FXML
    void initialize() {


        final reclamationService rs = new reclamationService();
        try {
            List<reclamation> reclamations = rs.displayList();
            ObservableList<reclamation> observableList = FXCollections.observableList(reclamations);
            showreclamation.setItems(observableList);

            desccolone.setCellValueFactory(new PropertyValueFactory<>("description"));
            typecolone.setCellValueFactory(new PropertyValueFactory<>("type"));
            datecolone.setCellValueFactory(new PropertyValueFactory<>("date"));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }


    // List<reclamation> reclamations= this.rs.displayList();
    // ObservableList<reclamation> observableList= FXCollections.observableList(reclamations);
    //showreclamation.setItems(observableList);*/
    //desccolone.setCellValueFactory(new PropertyValueFactory<>("descriptiion"));
    //typecolone.setCellValueFactory(new PropertyValueFactory<>("type"));
    // datecolone.setCellValueFactory(new PropertyValueFactory<>("date"));





    @FXML
    private void handeltraitbutton(ActionEvent event) throws Exception {
        // changerInterface (ActionEvent event) throws Exception {
        // Charger la deuxième interface à partir du fichier FXML
        Parent root = FXMLLoader.load(getClass().getResource("/showtraitement.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();
    }

    /*public static void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }*/



    public boolean showConfirmationAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText(null);
        alert.setContentText(message);

        // Définir les boutons "Oui" et "Non"
        ButtonType buttonTypeYes = new ButtonType("Oui");
        ButtonType buttonTypeNo = new ButtonType("Non");

        // Ajouter les boutons à la boîte de dialogue
        alert.getButtonTypes().setAll(buttonTypeYes, buttonTypeNo);

        // Afficher la boîte de dialogue et attendre la réponse de l'utilisateur
        alert.showAndWait();

        // Retourner vrai si l'utilisateur a cliqué sur "Oui", faux sinon
        return alert.getResult() == buttonTypeYes;
    }

   @FXML
    public void handelsupprecbuton(ActionEvent actionEvent) throws IOException, SQLException {
        // changerInterface (ActionEvent event) throws Exception {
        // Charger la deuxième interface à partir du fichier FXML
        Parent root = FXMLLoader.load(getClass().getResource("/deleterelamation.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();

        if (showConfirmationAlert("Voulez-vous vraiment supprimer cet élément?")) {
            // Logique de suppression ici
            System.out.println("Suppression confirmée.");
        } else {
            // L'utilisateur a choisi "Non", ne rien faire
            System.out.println("Suppression annulée.");


        }
    }

        //private static void showAlert(java.lang.String reclamationSupprimée, java.lang.String s) {}



   /* public void handleUpdateButton(ActionEvent actionEvent) throws IOException {
        // changerInterface (ActionEvent event) throws Exception {
        // Charger la deuxième interface à partir du fichier FXML
        Parent root = FXMLLoader.load(getClass().getResource("/modifreclamation.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();
    }*/
}

