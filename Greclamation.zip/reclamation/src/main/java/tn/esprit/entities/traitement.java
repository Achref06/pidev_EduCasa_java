package tn.esprit.entities;

public class traitement {
    private int idT;
    private int numR;

    private String reponse;


    public traitement() {
    }

    ;

    /* public traitement( String reponse, int numR) {
         this.idT =idT;
         this.reponse =reponse;
         this.numR=numR;
     }*/
    public traitement(int numR, String reponse) {
        //this.idT=idT;
        this.numR = numR;
        this.reponse = reponse;


    }

    public traitement(String text, String text1, String text2) {
    }

    public traitement(String text, String text1) {
    }

    public traitement(String text) {
    }


    // public traitement(int idt, String reponse){};


    @Override
    public String toString() {
        return "traitement{" +
                "idT=" + idT +
                ", numR=" + numR +
                ", reponse='" + reponse + '\'' +
                '}';
    }

    public int getIdT() {
        return idT;
    }

    public void setIdT(int idt) {
        this.idT = idT;
    }

    public String getReponse() {
        return reponse;
    }

    public void setReponse(String reponse) {
        this.reponse = reponse;
    }

    public int getNumR() {
        return numR;
    }

    public void setNumR(int numR) {
        this.numR = numR;
    }

    private reclamation reclamation;

    // Autres attributs et méthodes

    public reclamation getReclamation() {
        return reclamation;
    }

    public void setReclamation(reclamation reclamation) {
        this.reclamation = reclamation;
    }
}


