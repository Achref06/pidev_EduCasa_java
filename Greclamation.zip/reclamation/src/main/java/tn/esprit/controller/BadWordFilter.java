package tn.esprit.controller;
import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;
import org.json.JSONObject;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;

import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BadWordFilter {
    private static final String API_KEY = "4d7d569e00msh2f65f7c0617c911p181ffbjsn659a6daab228";
    private static final String API_HOST = "nobadwords1.p.rapidapi.com";

    public static String filterBadWords(String input) {

        //public static String Filter(String content) {
        //Object content = null;
        HttpResponse<String> response = Unirest.post("https://neutrinoapi-bad-word-filter.p.rapidapi.com/bad-word-filter")
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .header("X-RapidAPI-Key", API_KEY)
                    .header("X-RapidAPI-Host", "neutrinoapi-bad-word-filter.p.rapidapi.com")
                    .field("content", input)
                    .field("censor-character", "*")
                    .asString();

            if (response.getStatus() == 200) {
                String filteredText = response.getBody();

                // Remplacement des mots interdits par des étoiles
                String regex = "\\b(badword1|badword2|badword3)\\b"; // Remplacez badword1, badword2, badword3 par vos mots interdits
                Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
                Matcher matcher = pattern.matcher(filteredText);
                filteredText = matcher.replaceAll("***");

                return filteredText;

            } else {
                System.err.println("Error: " + response.getStatusText());
                return null; // Retourne le contenu d'origine en cas d'erreur
            }
        }


}
