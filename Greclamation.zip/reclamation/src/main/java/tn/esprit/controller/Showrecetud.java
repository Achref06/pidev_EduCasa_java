package tn.esprit.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.Calendar;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.asynchttpclient.AsyncHttpClient;
import org.asynchttpclient.DefaultAsyncHttpClient;
import org.asynchttpclient.*;
import java.util.concurrent.CompletableFuture;
import java.util.List;

import java.util.concurrent.ExecutionException;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import tn.esprit.services.reclamationService;
import tn.esprit.entities.reclamation;

import static java.util.Date.*;


public class Showrecetud {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableView<reclamation> showreclamation;

    @FXML
    private TableColumn<?, ?> desccolone;

    @FXML
    private TableColumn<?, ?> typecolone;

    @FXML
    private TableColumn<?, ?> datecolone;

    @FXML
    private Button ajouterrec;

    @FXML
    private Button modreclamation;

    @FXML
    private Button suppreclamation;
    @FXML
    private Button traduireR;
    private reclamation r;
    public tn.esprit.services.reclamationService rs;
    private Object event;


    @FXML
        private void handleTableClick(MouseEvent event) {

            // Vérifier si l'événement est un double clic et si la souris est sur le TableView
            if (event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() == 2 && event.getTarget() instanceof TableRow) {
                // Récupérer la ligne sur laquelle l'utilisateur a cliqué
                TableRow<reclamation> row = (TableRow<reclamation>) event.getTarget();
                reclamation selectedElement = row.getItem();

                if (selectedElement != null) {
                    // Afficher une boîte de dialogue de confirmation pour la modification ou la suppression
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Confirmation");
                    alert.setHeaderText(null);
                    alert.setContentText("Voulez-vous modifier ou supprimer l'élément sélectionné?");

                    // Ajouter les boutons "Modifier" et "Supprimer"
                    ButtonType buttonTypeModify = new ButtonType("Modifier");
                    ButtonType buttonTypeDelete = new ButtonType("Supprimer");
                    ButtonType buttonTypeCancel = new ButtonType("Annuler", ButtonBar.ButtonData.CANCEL_CLOSE);
                    alert.getButtonTypes().setAll(buttonTypeModify, buttonTypeDelete, buttonTypeCancel);

                    // Attendre la réponse de l'utilisateur
                    Optional<ButtonType> result = alert.showAndWait();
                    if (result.isPresent()) {
                        if (result.get() == buttonTypeModify) {
                            // L'utilisateur a choisi de modifier l'élément
                            // Ajoutez votre logique de modification ici
                        } else if (result.get() == buttonTypeDelete) {
                            // L'utilisateur a choisi de supprimer l'élément
                            // Ajoutez votre logique de suppression ici
                        } else {
                            // L'utilisateur a choisi d'annuler
                        }
                    }
                }
            }
        }



    @FXML
    void handleDeleteButton(ActionEvent event) throws IOException {
        reclamation selectedrec = showreclamation.getSelectionModel().getSelectedItem();

        if (selectedrec != null) {
            showreclamation.getItems().remove(selectedrec);

            reclamationService reclamationService = new reclamationService();
            try {
                reclamationService.delete(selectedrec);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("reclamation a été supprimé avec succès");
            alert.show();
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setContentText("Veuillez sélectionner une reclamation à supprimer.");
            alert.show();
        }
    }

        /*Parent root = FXMLLoader.load(getClass().getResource("/deleterelamation.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();

        if (showConfirmationAlert("Voulez-vous vraiment modifier cet élément?")) {
            // Logique de modification ici
            System.out.println("Modification confirmée.");
        } else {
            // L'utilisateur a choisi "Non", ne rien faire
            System.out.println("Modification annulée.");
        }*/



    public boolean showConfirmationAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText(null);
        alert.setContentText(message);

        // Définir les boutons "Oui" et "Non"
        ButtonType buttonTypeYes = new ButtonType("Oui");
        ButtonType buttonTypeNo = new ButtonType("Non");

        // Ajouter les boutons à la boîte de dialogue
        alert.getButtonTypes().setAll(buttonTypeYes, buttonTypeNo);

        // Afficher la boîte de dialogue et attendre la réponse de l'utilisateur
        alert.showAndWait();

        // Retourner vrai si l'utilisateur a cliqué sur "Oui", faux sinon
        return alert.getResult() == buttonTypeYes;
    }



        @FXML
        void handleUpdateButton (ActionEvent event) throws IOException {

            reclamation selectrec = showreclamation.getSelectionModel().getSelectedItem();

            if (selectrec != null) {
                // Show a confirmation alert before proceeding with modification
                Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
                confirmationAlert.setContentText("Voulez-vous vraiment modifier ce reclamation ?");

                // Show the confirmation dialog and wait for the user's response
                Optional<ButtonType> result = confirmationAlert.showAndWait();

                // Supposons que 'desccolone' est une TableColumn dans votre TableView
                TableColumn<reclamation, LocalDate> desccolone = new TableColumn<>("incident");

// Pour accéder à la valeur d'une cellule dans cette colonne, vous devez utiliser une cellule
                desccolone.setCellValueFactory(new PropertyValueFactory<>("nomDeLaPropriété"));
                // Check if the user clicked the "OK" button
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    // If the user clicked "OK", proceed with modifying the form
                    selectrec.setDescription(desccolone.getText());
                    selectrec.setType(typecolone.getText());
                    //selectrec.setDate(datecolone.getCellFactory());


                    //  selectrec.setDate(selectedItem.getDatecolone());

                    // Refresh the table view to reflect the changes
                    showreclamation.refresh();

                    // Update the form in the database
                    reclamationService rs = new reclamationService();
                    try {
                        rs.update(r);
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }

                    // Show a success message
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setContentText("reclamation a été modifié avec succès");
                    alert.show();
                }
            } else {
                // If no form is selected, show a warning message
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setContentText("Veuillez sélectionner un reclamation à modifier.");
                alert.show();
            }

            /*Parent root = FXMLLoader.load(getClass().getResource("/modifreclamation.fxml"));
            Scene scene = new Scene(root);

            // Obtenir la fenêtre actuelle
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Changer la scène pour afficher la deuxième interface
            stage.setScene(scene);
            stage.show();


            if (showConfirmationAlert("Voulez-vous vraiment modifier cet élément?")) {
                // Logique de modification ici
                System.out.println("Modification confirmée.");
            } else {
                // L'utilisateur a choisi "Non", ne rien faire
                System.out.println("Modification annulée.");
            }*/
        }


    @FXML
    void handleajouterButton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/ajouterreclamation.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();

    }



    @FXML
    void handeltraductionRbuton(ActionEvent event) throws IOException {

        String sourceLanguage = "fr"; // Langue source (anglais)
        String targetLanguage = "en"; // Langue cible (français)

        // Obtenez l'objet sélectionné ou les objets sélectionnés dans votre TableView
        reclamation selectedObject = showreclamation.getSelectionModel().getSelectedItem();

        if (selectedObject != null) {
            CompletableFuture<String> translationFuture = translator.translateDescription(selectedObject.getdesccolone, sourceLanguage, targetLanguage);

            translationFuture.thenAccept(translation -> {
                // Mettez à jour votre objet avec la traduction
                selectedObject.setTranslatedDescription(translation);

                // Rafraîchissez la vue pour afficher la traduction mise à jour
                // Cela dépend de votre implémentation, vous pouvez appeler une méthode pour rafraîchir la vue ici
            });
        }
    }


       /* String apiKey = "4d7d569e00msh2f65f7c0617c911p181ffbjsn659a6daab228"; // Remplacez "VOTRE_CLÉ_API" par votre propre clé d'API

        AsyncHttpClient client = new DefaultAsyncHttpClient();
        client.prepare("GET", "https://text-translator2.p.rapidapi.com/getLanguages")
                .setHeader("X-RapidAPI-Key", "4d7d569e00msh2f65f7c0617c911p181ffbjsn659a6daab228")
                .setHeader("X-RapidAPI-Host", "text-translator2.p.rapidapi.com")
                .execute()
                .toCompletableFuture()
                .thenAccept(System.out::println)
                .join();

        client.close();
    }*/



    @FXML
    void initialize() {
        final reclamationService rs = new reclamationService();
        try {
            List<reclamation> reclamations = rs.displayList();
            ObservableList<reclamation> observableList = FXCollections.observableList(reclamations);
            showreclamation.setItems(observableList);

            desccolone.setCellValueFactory(new PropertyValueFactory<>("description"));
            typecolone.setCellValueFactory(new PropertyValueFactory<>("type"));
            datecolone.setCellValueFactory(new PropertyValueFactory<>("date"));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }
}

