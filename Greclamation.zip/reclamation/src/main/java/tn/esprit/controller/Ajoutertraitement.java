

package tn.esprit.controller;

        import java.io.IOException;
        import java.net.URL;
        import java.sql.SQLException;
        import java.text.DateFormat;
        import java.text.ParseException;
        import java.text.SimpleDateFormat;
        import java.util.List;
        import java.util.ResourceBundle;

        import javafx.fxml.FXMLLoader;
        import javafx.scene.Node;
        import javafx.scene.Parent;
        import javafx.scene.Scene;
        import javafx.scene.control.Button;


        import javafx.collections.FXCollections;
        import javafx.collections.ObservableList;
        import javafx.fxml.FXML;
        import javafx.event.ActionEvent;

        import javafx.scene.control.TableColumn;
        import javafx.scene.control.TableView;
        import javafx.scene.control.TextField;
        import javafx.scene.control.cell.PropertyValueFactory;
        import javafx.stage.Stage;
        import tn.esprit.entities.reclamation;
        import tn.esprit.entities.traitement;
        import tn.esprit.services.reclamationService;
        import tn.esprit.services.traitementServices;

        import javafx.scene.control.Alert;

public class Ajoutertraitement {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    @FXML
    private TextField idTadd;


    @FXML
    private TextField numRadd;

    @FXML
    private TextField reponseadd;

    @FXML
    private Button ajoutertraitement;
    @FXML
    private Button envoyermail;


    private final traitementServices ts=new traitementServices();
    private traitement traitement;
    private String reponse;
    private int numR;

    @FXML
    void handleajoutraitbuton(ActionEvent event) throws IOException {
        try {
            int numR = Integer.parseInt(numRadd.getText());
            String reponse = reponseadd.getText();
            traitement traitement1 = new traitement(numR, reponse);
            ts.addT(traitement1);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Confirmation");
            alert.setContentText("A new reclamation is added");
            alert.showAndWait();
        } catch (IllegalArgumentException | SQLException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setContentText(e.getMessage());
            alert.showAndWait();
        }
    }
        /*try {
            traitement traitement1 = new traitement(numR, reponse);


            // Add the reservation using the parsed date and payment method
            ts.addT(new traitement(numRadd.getText(), reponseadd.getText()));

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Confirmation");
            alert.setContentText("A new reclamation is added");
            alert.showAndWait();

            //  clearFields();

        } catch (IllegalArgumentException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setContentText(e.getMessage());
            alert.showAndWait();
            // clearFields();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } //catch (ParseException e) {
            //throw new RuntimeException(e);
        }*/

        // Proceed with adding the activity
        /*try {
            // Validate all fields are not empty
            // String id = idTadd.getText();
            String reponse = reponseadd.getText();
            String numR = numRadd.getText();

            if (reponse.isEmpty() || numR.isEmpty()) {
                throw new IllegalArgumentException("tous les champs doivent etre remplis.");
            }

            // Create a new Activity object with the converted Date and image file path
            traitement traitement1 = new traitement(numR, reponse);

            // Add the activity to the database
            ts.addT(traitement1);

            // Refresh the TableView


            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Confirmation");
            alert.setContentText("traitement ajouter avec succes");
            alert.showAndWait();

        } catch (IllegalArgumentException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setContentText(e.getMessage());
            alert.showAndWait();



        } catch (SQLException e) {
            throw new RuntimeException(e);
        }*/

    @FXML
    void handelmailbuton(ActionEvent event) throws IOException {
        String recipientEmail = "nermine.ghouibii@gmail.com";
        String subject = "reclamation";
        String body = "votre reclamation a ete traite avec succes";

        // Créer une instance de EmailSender
        emaisender emailSender = new emaisender();

        // Appeler la méthode sendEmail
        emailSender.sendEmail(recipientEmail, subject, body);
        // Après avoir résolu une réclamation
        /*recipientEmail = "nermine.ghouibii@gmail.com";
        String surveyLink = "https://docs.google.com/forms/d/14kYvwjN8lrGo8v04QtYl08VpyLi5p4nvhN7v4eleN78/edit";
        EmailFeedbackCollector.sendFeedbackEmail(recipientEmail, surveyLink);
*/

        /*try {
            EmailFeedbackCollector.sendFeedbackEmail("nermine.ghouibii@gmail.com", "https://docs.google.com/forms/d/14kYvwjN8lrGo8v04QtYl08VpyLi5p4nvhN7v4eleN78/edit");
        } catch (Exception e) {
            e.printStackTrace(); // Gérer les exceptions
        }*/


        Parent root = FXMLLoader.load(getClass().getResource("/showtraitement.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();

    }

   /* void ajoutertraitement(ActionEvent event) {
        traitement traitement = new traitement(idTadd.getText(), numRadd.getText(), reponseadd.getText());
        traitementServices traitementServices = new traitementServices();
        try {
            traitementServices.addT(traitement);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText("traitement ajoutee ");
        alert.show();


    }*/
    @FXML
    void initialize() {
        /*try {
            List<traitement> traitements= ts.displayList();
            ObservableList<traitement> observableList= FXCollections.observableList(traitements);
            showtraitment.setItems(observableList);
            idTshow.setCellValueFactory(new PropertyValueFactory<>("idT"));
            numRshow.setCellValueFactory(new PropertyValueFactory<>("numR"));
            reponseShow.setCellValueFactory(new PropertyValueFactory<>("reponse"));

        }catch(SQLException e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText( e.getMessage());
            alert.showAndWait();
        }*/
    }

    }

