package tn.esprit.controller;
import org.asynchttpclient.*;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import kong.unirest.Unirest;

import org.asynchttpclient.*;

import java.util.concurrent.CompletableFuture;

public class translator {

    private static final String API_KEY = "4d7d569e00msh2f65f7c0617c911p181ffbjsn659a6daab228";
    private static final String API_HOST = "text-translator2.p.rapidapi.com";

    public static CompletableFuture<String> translateDescription(String desccolone, String sourceLanguage, String targetLanguage) {
        String url = "https://text-translator2.p.rapidapi.com/translate";
        String body = "source_language=" + sourceLanguage + "&target_language=" + targetLanguage + "&text=" + desccolone;

        return Unirest.post(url)
                .header("X-RapidAPI-Key", API_KEY)
                .header("X-RapidAPI-Host", API_HOST)
                .header("Content-Type", "application/x-www-form-urlencoded")
                .body(body)
                .asStringAsync()
                .thenApply(response -> {
                    if (response.isSuccess()) {
                        return response.getBody();
                    } else {
                        return "Error: " + response.getStatus();
                    }
                });
    }

    /*private static final String API_KEY = "4d7d569e00msh2f65f7c0617c911p181ffbjsn659a6daab228";
    private static final String API_HOST = "text-translator2.p.rapidapi.com";

    public static CompletableFuture<String> translateDescription(String desccolone, String sourceLanguage, String targetLanguage) {
       try (AsyncHttpClient asyncHttpClient =  Unirest.asyncHttpClient()) {

            String url = "https://text-translator2.p.rapidapi.com/translate";
            String body = "source_language=" + sourceLanguage + "&target_language=" + targetLanguage + "&text=" + desccolone;

            HttpRequestWithBody request = Unirest.post(url)
                    .header("X-RapidAPI-Key", API_KEY)
                    .header("X-RapidAPI-Host", API_HOST)
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .body(body);

            return request.asStringAsync()
                    .thenApply(response -> {
                        if (response.getStatus() == 200) {
                            return response.getBody();
                        } else {
                            return "Error: " + response.getStatus();
                        }
                    });
        } catch (Exception e) {
            // Gérer l'exception, si nécessaire
            e.printStackTrace();
            return CompletableFuture.completedFuture("Error: " + e.getMessage());
        }
    }*/
}
