package tn.esprit.controller;
import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;
import tn.esprit.entities.reclamation;
//import org.json.JSONObject;
import kong.unirest.json.JSONObject;


public class emaisender {
    public static void sendEmail(String recipientEmail, String subject, String body) {
        String apiKey = "4d7d569e00msh2f65f7c0617c911p181ffbjsn659a6daab228";
        String url = "https://mail-sender-api1.p.rapidapi.com/";

        // Ajoutez le lien vers le formulaire à la fin du corps du message
        String feedbackFormUrl = "https://docs.google.com/forms/d/14kYvwjN8lrGo8v04QtYl08VpyLi5p4nvhN7v4eleN78/edit";
        String bodyWithFormLink = body + "\n\nPour remplir le formulaire de feedback, veuillez cliquer sur le lien suivant : " + feedbackFormUrl;

        JSONObject requestBody = new JSONObject();
        requestBody.put("sendto", recipientEmail);
        requestBody.put("name", "educasa");
        requestBody.put("replyTo", "Your Email address where users can send their reply");
        requestBody.put("ishtml", "false");
        requestBody.put("title", subject);
        requestBody.put("body", bodyWithFormLink);
        try{

        HttpResponse<JsonNode> response = Unirest.post(url)
                .header("Content-Type", "application/json")
                .header("X-RapidAPI-Key", apiKey)
                .header("X-RapidAPI-Host", "mail-sender-api1.p.rapidapi.com")
                .body(requestBody)
                .asJson();

        int status = response.getStatus();
        System.out.println("Response status: " + status);
        

        // Vérifier si la réponse est vide ou si elle contient des données
        /*if (response.getBody() != null ) {
            JSONObject responseBody = response.getBody().getObject();
            if (responseBody.has("message")) {
                String errorMessage = responseBody.getString("message");
                System.out.println("Error message: " + errorMessage);
            } else {
                System.out.println("No error message found in the response.");
            }
        } else {
            System.out.println("Empty response body received.");
        }*/

        if (status == 200) {
            System.out.println("Email sent successfully.");
        } else {
            System.out.println("Failed to send email.");
        }
        } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
            }
            //System.out.println("Error message: " + response.getBody().getObject().getString("message"));

    }
}
