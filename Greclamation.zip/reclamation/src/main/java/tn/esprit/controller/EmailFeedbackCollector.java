package tn.esprit.controller;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.*;
import java.util.Properties;


public class EmailFeedbackCollector {
    public static void sendFeedbackEmail(String recipientEmail, String surveyLink ) {
        // Configuration de la session SMTP
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com"); // Remplacez par votre serveur SMTP
        props.put("mail.smtp.port", "587"); // Port SMTP

        // Informations d'authentification
        String username = "nermine.ghouibii@gmail.com"; // Votre adresse e-mail
        String password = "narmoucha14"; // Votre mot de passe

        // Création d'une nouvelle session avec authentification
        Session session = Session.getInstance(props,
                new Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {
            // Création du message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username)); // Adresse e-mail de l'expéditeur
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(recipientEmail)); // Adresse e-mail du destinataire
            message.setSubject("Feedback sur la gestion de votre réclamation");

            // Contenu de l'e-mail (lien vers un formulaire de feedback)
            String feedbackFormUrl = "https://docs.google.com/forms/d/14kYvwjN8lrGo8v04QtYl08VpyLi5p4nvhN7v4eleN78/edit";
            String emailContent = "Bonjour,\n\n"
                    + "Nous espérons que votre réclamation a été résolue de manière satisfaisante. "
                    + "Nous aimerions recueillir votre avis sur la façon dont nous avons géré votre réclamation. "
                    + "Veuillez prendre quelques instants pour remplir notre formulaire de feedback en cliquant sur le lien ci-dessous :\n\n"
                    + feedbackFormUrl + "\n\n"
                    + "Nous apprécions votre retour et vous remercions pour votre collaboration.\n\n"
                    + "Cordialement,\n"
                    + "Votre équipe de service client";

            // Définition du contenu du message
            message.setText(emailContent);

            // Envoi du message
            Transport.send(message);

            System.out.println("E-mail de feedback envoyé avec succès.");

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}
