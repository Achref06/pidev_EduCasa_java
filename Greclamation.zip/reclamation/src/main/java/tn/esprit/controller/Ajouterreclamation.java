
package tn.esprit.controller;

import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.sql.Date;




import javafx.event.ActionEvent;
import javafx.scene.control.Button;

import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert;

import javafx.stage.Stage;
import tn.esprit.services.reclamationService;
import tn.esprit.entities.reclamation;
        import java.net.URL;


import java.util.ResourceBundle;


import java.io.IOException;
import java.sql.SQLException;

public class Ajouterreclamation {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;


    @FXML
    private Button ajouterreclamation;

    @FXML
    private TextField descTextfeild;

    @FXML
    private TextField dateadd;

    @FXML
    private ChoiceBox<String> typeadd;

    private reclamation r;
    private final reclamationService rs = new reclamationService();
    private LocalDate localDate;

   /*public static boolean validateNotEmpty(TextField... fields) {
        for (TextField field : fields) {
            // Vérifier si le champ est vide ou null
            if (field.getText() == null || field.getText().isEmpty()) {
                return false;
            }
        }
        return true; // Tous les champs ne sont pas vides
    }*/

    @FXML
    void initialize() {
        typeadd.getItems().add("cours");
        typeadd.getItems().add("prof");
        typeadd.getItems().add("etudiant");


    }

    private int getActivityID(String type) throws SQLException {
        reclamationService reclamationService = new reclamationService();
        return reclamationService.getActivityIDByName(type);
    }

    @FXML
    void handelajouterButon(ActionEvent event) throws IOException {
        try {
            // Parse date_reserv text into a Date object
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date utilDate = dateFormat.parse(dateadd.getText());
            java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

            //Date date = (Date) dateFormat.parse(dateadd.getText());

            // Add the reservation using the parsed date and payment method
            rs.add(new reclamation(descTextfeild.getText(), typeadd.getValue().toString(), sqlDate));

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Confirmation");
            alert.setContentText("A new reclamation is added");
            alert.showAndWait();

            //  clearFields();

        } catch (IllegalArgumentException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setContentText(e.getMessage());
            alert.showAndWait();
            // clearFields();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        // Proceed with adding the activity
      /*  try {
            String typechoiceBOX = typeadd.getValue();
            int IDactInt = getActivityID(typechoiceBOX);

            // Validate all fields are not empty
            String description = descTextfeild.getText();
            String type = typeadd.getValue();
            LocalDate date = datepicker.getValue(); // Retrieve selected date from DatePicker
            System.out.println(type+datepicker.getValue()+description);
            if (description.isEmpty() || date == null || type == null) {
                throw new IllegalArgumentException("All fields must be filled out.");
            }

            // Validate name input
           /* if (!t.matches("[a-zA-Z ]+")) {
                throw new IllegalArgumentException("Name must contain only letters.");
            }*/

        // Convert LocalDate to java.sql.Date
        //java.sql.Date sqlDate = java.sql.Date.valueOf(Date);

        // Create a new Activity object with the converted Date and image file path
        //reclamation reclamation = new reclamation(type, description,sqlDate);

        // Add the activity to the database
           /* try {
                rs.add(r);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
*/
        // Refresh the TableView
        //RefreshTableView();

            /*Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Confirmation");
            alert.setContentText("A new Activity is Added");
            alert.showAndWait();
*/
        //clearFields();

       /* } catch (IllegalArgumentException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setContentText(e.getMessage());
            alert.showAndWait();

            //clearFields();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }*/

    }
}
       /* String description = descTextfeild.getText();
        String type = typeadd.getValue();
        LocalDate date = datepicker.getValue();
        System.out.println("Description: " + description);
        System.out.println("Type: " + type);
        System.out.println("date: " + date);

         if (description.isEmpty() || type == null || date == null) {
             Alert alert = new Alert(Alert.AlertType.ERROR);
             alert.setContentText("Veuillez sélectionner une date et un statut.");
             alert.show();
             return;
        // System.out.println("Veuillez remplir tous les champs.");
    }
            reclamation reclamation = new reclamation(description, type, date);
            reclamationService reclamationService = new reclamationService();

            try {
                reclamationService.add(reclamation);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Réclamation ajoutée avec succès.");
                alert.show();

                // Charger une autre interface après l'ajout de la réclamation
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/showrecetud.fxml"));
                Parent root = loader.load();
                reclamation reclamation1 = loader.getController();
                reclamation1.setDate(Date.valueOf(datepicker.getValue()).toLocalDate());
                reclamation1.setType(typeadd.getValue());
                typeadd.getScene().setRoot(root);
                /*Scene scene = new Scene(root);
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.show();
            } catch (SQLException e) {
                // Gérer l'exception de manière appropriée, par exemple afficher un message à l'utilisateur
                System.out.println("Erreur lors de l'ajout de la réclamation : " + e.getMessage());
            } catch (IOException e) {
                // Gérer l'exception de manière appropriée, par exemple afficher un message à l'utilisateur
                System.out.println("Erreur lors du chargement de l'interface : " + e.getMessage());
            }
        }*/

       /* reclamation reclamation = new reclamation(descTextfeild.getText(), typeadd.getValue(), datepicker.getValue());
        reclamationService reclamationService = new reclamationService();

        try {
            reclamationService.add(reclamation);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("reclamation ajoutee ");
            alert.show();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        try {
            Parent root = FXMLLoader.load(getClass().getResource("/showrecetud.fxml"));
            Scene scene = new Scene(root);

            // Obtenir la fenêtre actuelle
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Changer la scène pour afficher la deuxième interface
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

            String description = descTextfeild.getText();
            String type = typeadd.getValue();
            LocalDate localDate = datepicker.getValue();

            if (description.isEmpty() || type == null || localDate == null) {
                System.out.println("veuiller remplir tout les champs");

            }*/




        // reclamation reclamation = new reclamation(descTextfeild.getText(),datepicker.getValue(),typeadd.getValue());
        /*reclamation reclamation = new reclamation(descTextfeild.getText(),  typeadd.getValue(), datepicker.getValue());
        reclamationService reclamationService = new reclamationService();
        try {
            reclamationService.add(reclamation);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText("Le formulaire a été ajouté avec succès.");
        alert.show();*/
        /*FXMLLoader loader = new FXMLLoader(getClass().getResource("/FormInfo.fxml"));
        try {
            Parent root = loader.load();
            FormInfo formInfo = loader.getController();
            formInfo.setDate(String.valueOf(dateTextField.getValue()));
            formInfo.setStatut(statutTextField.getValue());
            statutTextField.getScene().setRoot(root);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }*/





        /*if (validateNotEmpty(descTextfeild)) {
            System.out.println("veuiller remplir la description pour ajouter la reclamation");
        } else {
            System.out.println("veuiller remplir la description pour ajouter la reclamation");
        }*/




   /* public static boolean validateFields(TextField fields) {

        return fields.getText() !=null && !fields.getText().trim().isEmpty(); // Tous les champs sont valides
    }*/


        /*@FXML
        void initialize () {
            typeadd.getItems().add("cours");
            typeadd.getItems().add("prof");
            typeadd.getItems().add("etudiant");

        }*/









