package tn.esprit.controller;


import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.scene.control.*;
import tn.esprit.entities.traitement;
import tn.esprit.services.traitementServices;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;


import javafx.scene.control.cell.PropertyValueFactory;

import javafx.stage.Stage;
import tn.esprit.entities.reclamation;
import tn.esprit.services.reclamationService;


import static tn.esprit.controller.BadWordFilter.filterBadWords;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
//import tn.esprit.entities.StatistiqueReclamation;


public class Showrecprof {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;


    @FXML
    private Button showtraitement;

    @FXML
    private Button modreclamation;

    @FXML
    private Button suppreclamation;
    @FXML
    private Button stat;


    /*  @FXML
      private Button addButton;*/


    @FXML
    private TableView<reclamation> showreclamation;
    @FXML
    private TableColumn<reclamation, String> descriptionColumn;

    @FXML
    private TableColumn<?, ?> desccolone;

    @FXML
    private TableColumn<?, ?> typecolone;

    @FXML
    private TableColumn<?, ?> datecolone;

    @FXML
    private ListView<reclamation> reclamationListView;
    private tn.esprit.services.reclamationService rs;
    private List<tn.esprit.entities.reclamation> reclamations = new ArrayList<>();
    private String title;
    private Object String;
    private java.lang.String content;
    private tn.esprit.entities.reclamation reclamation;
    private traitementServices ts;
    private tn.esprit.entities.traitement traitement;


    /*@FXML
    private void handleTableRowClick(MouseEvent event) throws IOException {

        // Vérifier si l'événement est un double clic et si la souris est sur le TableView
        if (event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() == 2 && event.getTarget() instanceof TableRow) {
            // Récupérer la ligne sur laquelle l'utilisateur a cliqué
            TableRow<reclamation> row = (TableRow<reclamation>) event.getTarget();
            reclamation selectedElement = row.getItem();

            if (selectedElement != null) {
                // Afficher une boîte de dialogue de confirmation pour la modification ou la suppression
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation");
                alert.setHeaderText(null);
                alert.setContentText("Voulez-vous traiter ou supprimer l'élément sélectionné?");

                // Ajouter les boutons "Modifier" et "Supprimer"
                ButtonType buttonTypetraiter = new ButtonType("traiter");
                ButtonType buttonTypeDelete = new ButtonType("Supprimer");
                ButtonType buttonTypeCancel = new ButtonType("Annuler", ButtonBar.ButtonData.CANCEL_CLOSE);
                alert.getButtonTypes().setAll(buttonTypetraiter, buttonTypeDelete, buttonTypeCancel);

                // Attendre la réponse de l'utilisateur
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent()) {
                    if (result.get() == buttonTypetraiter) {
                        // L'utilisateur a choisi de modifier l'élément
                        Parent root = FXMLLoader.load(getClass().getResource("/showtraitement.fxml"));
                        Scene scene = new Scene(root);

                        // Obtenir la fenêtre actuelle
                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

                        // Changer la scène pour afficher la deuxième interface
                        stage.setScene(scene);
                        stage.show();

                        }
                    } else if (result.get() == buttonTypeDelete) {
                    Parent root = FXMLLoader.load(getClass().getResource("/deleterelamation.fxml"));
                    Scene scene = new Scene(root);

                    // Obtenir la fenêtre actuelle
                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

                    // Changer la scène pour afficher la deuxième interface
                    stage.setScene(scene);
                    stage.show();

                    if (showConfirmationAlert("Voulez-vous vraiment supprimer cet élément?")) {
                        // Logique de suppression ici
                        System.out.println("Suppression confirmée.");
                    } else {
                        // L'utilisateur a choisi "Non", ne rien faire
                        System.out.println("Suppression annulée.");


                    }
                    } else {
                        // L'utilisateur a choisi d'annuler
                    }
                }
            }
        }*/


    @FXML
    void initialize() {


        final reclamationService rs = new reclamationService();
        try {
            List<reclamation> reclamations = rs.displayList();
            // Filtrer les mots interdits dans la description de chaque réclamation
            for (reclamation reclamation : reclamations) {
                String filteredDescription = filterBadWords(reclamation.getDescription());
                reclamation.setDescription(filteredDescription); // Mettre à jour la description filtrée
            }

            // Convertir la liste filtrée en une liste observable pour l'affichage dans le TableView
            ObservableList<reclamation> observableReclamations = FXCollections.observableArrayList(reclamations);

            // Définir les éléments du TableView
            showreclamation.setItems(observableReclamations);

            // Définir les cellules de la colonne de description
            desccolone.setCellValueFactory(new PropertyValueFactory<>("description"));
            typecolone.setCellValueFactory(new PropertyValueFactory<>("type"));
            datecolone.setCellValueFactory(new PropertyValueFactory<>("date"));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        //final reclamationService rs = new reclamationService();

    }


    /*public void handleAdminTextSubmission(String text, boolean removeBadWords) {
        // Si removeBadWords est vrai, filtrez les gros mots
        if (removeBadWords) {
            text = filterBadWords(text);
            String recipientEmail = "nermine.ghouibii@gmail.com";
            String subject = "reclamation sonctionnee";
            String body = "votre reclamation contient des gros mots";

            // Créer une instance de EmailSender
            emaisender emailSender = new emaisender();

            // Appeler la méthode sendEmail
            emailSender.sendEmail(recipientEmail, subject, body);
        }
    }*/


    // List<reclamation> reclamations= this.rs.displayList();
    // ObservableList<reclamation> observableList= FXCollections.observableList(reclamations);
    //showreclamation.setItems(observableList);*/
    //desccolone.setCellValueFactory(new PropertyValueFactory<>("descriptiion"));
    //typecolone.setCellValueFactory(new PropertyValueFactory<>("type"));
    // datecolone.setCellValueFactory(new PropertyValueFactory<>("date"));





    @FXML
    private void handeltraitbutton(ActionEvent event) throws Exception {
        // changerInterface (ActionEvent event) throws Exception {
        // Charger la deuxième interface à partir du fichier FXML
        /*Parent root = FXMLLoader.load(getClass().getResource("/showtraitement.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();*/


        showtraitement.setOnAction(actionEvent ->  {
            reclamation selectedReclamation = showreclamation.getSelectionModel().getSelectedItem();
            if (selectedReclamation == null) {
                showAlert("Aucune réclamation sélectionnée", "Veuillez sélectionner une réclamation avant de traiter.");
            } else {
                // Votre logique de traitement ici
                Parent root = null;
                try {
                    root = FXMLLoader.load(getClass().getResource("/showtraitement.fxml"));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                Scene scene = new Scene(root);

                // Obtenir la fenêtre actuelle
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

                // Changer la scène pour afficher la deuxième interface
                stage.setScene(scene);
                stage.show();
            }
        });

    }

    public static void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }



    public boolean showConfirmationAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText(null);
        alert.setContentText(message);

        // Définir les boutons "Oui" et "Non"
        ButtonType buttonTypeYes = new ButtonType("Oui");
        ButtonType buttonTypeNo = new ButtonType("Non");

        // Ajouter les boutons à la boîte de dialogue
        alert.getButtonTypes().setAll(buttonTypeYes, buttonTypeNo);

        // Afficher la boîte de dialogue et attendre la réponse de l'utilisateur
        alert.showAndWait();

        // Retourner vrai si l'utilisateur a cliqué sur "Oui", faux sinon
        return alert.getResult() == buttonTypeYes;
    }

   @FXML
    public void handelsupprecbuton(ActionEvent actionEvent) throws IOException, SQLException {
       tn.esprit.entities.reclamation selectedrec = showreclamation.getSelectionModel().getSelectedItem();

       if (selectedrec != null) {
           // Show a confirmation alert before proceeding with deletion
           Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
           confirmationAlert.setContentText("Voulez-vous vraiment supprimer cette reclamation ?");

           // Show the confirmation dialog and wait for the user's response
           Optional<ButtonType> result = confirmationAlert.showAndWait();

           // Check if the user clicked the "OK" button
           if (result.isPresent() && result.get() == ButtonType.OK) {
               // If the user clicked "OK", proceed with deleting the form

               // Remove the selected form from the table view
               showreclamation.getItems().remove(selectedrec);

               // Delete the form from the database
               reclamationService reclamationService = new reclamationService();
               reclamationService.delete(selectedrec);

               // Show a success message
               Alert alert = new Alert(Alert.AlertType.INFORMATION);
               alert.setContentText("reclamation a été supprimé avec succès");
               alert.show();
           }
       } else {
           // If no form is selected, show a warning message
           Alert alert = new Alert(Alert.AlertType.WARNING);
           alert.setContentText("Veuillez sélectionner un reclamation à supprimer.");
           alert.show();
       }
        // changerInterface (ActionEvent event) throws Exception {
        // Charger la deuxième interface à partir du fichier FXML
       /* Parent root = FXMLLoader.load(getClass().getResource("/deleterelamation.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();

        if (showConfirmationAlert("Voulez-vous vraiment supprimer cet élément?")) {
            // Logique de suppression ici
            System.out.println("Suppression confirmée.");
        } else {
            // L'utilisateur a choisi "Non", ne rien faire
            System.out.println("Suppression annulée.");


        }*/
    }

        //private static void showAlert(java.lang.String reclamationSupprimée, java.lang.String s) {}



   /* public void handleUpdateButton(ActionEvent actionEvent) throws IOException {
        // changerInterface (ActionEvent event) throws Exception {
        // Charger la deuxième interface à partir du fichier FXML
        Parent root = FXMLLoader.load(getClass().getResource("/modifreclamation.fxml"));
        Scene scene = new Scene(root);

        // Obtenir la fenêtre actuelle
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();

        // Changer la scène pour afficher la deuxième interface
        stage.setScene(scene);
        stage.show();
    }*/


}

