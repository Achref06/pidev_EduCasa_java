package tn.esprit.services;
import tn.esprit.Utils.myDB;

import tn.esprit.entities.reclamation;
import tn.esprit.entities.traitement;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class traitementServices implements Itraitement<traitement>{
    @Override
    public void addT(traitement traitement) throws SQLException {
        String requete = "INSERT INTO traitement (numR, reponse) VALUES (?, ?)";
        System.out.println("Requête SQL: " + requete); // Afficher la requête SQL pour vérification

        try {
            PreparedStatement pst = myDB.getInstance().getCon().prepareStatement(requete);
            pst.setInt(1, traitement.getNumR());
            pst.setString(2, traitement.getReponse());

            pst.executeUpdate();
            System.out.println("Reclamation ajoutée avec succès");
        } catch (SQLException e) {
            System.out.println("Erreur lors de l'exécution de la requête : " + e.getMessage());
        /*String requete = "INSERT INTO traitement ( numR,reponse  ) VALUES (?,?)";
        //try {
        PreparedStatement pst = myDB.getInstance().getCon().prepareStatement(requete);
        pst.setInt(1, traitement.getNumR());
        pst.setString(2, traitement.getReponse());


        pst.executeUpdate();
        System.out.println("reclamation ajoutee");*/
        /*String requete = "INSERT INTO traitement (  numR ,reponse ) VALUES (?,?)";
        try {
            PreparedStatement pst = myDB.getInstance().getCon().prepareStatement(requete);
           // pst.setInt(1, traitement.getIdT());
            pst.setInt(1, traitement.getNumR());
            pst.setString(2, traitement.getReponse());

            pst.executeUpdate();
            System.out.println("traitement ajoutee");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }*/
        }
    }


    @Override
    public void updateT(traitement traitement) throws SQLException {
        String requete = "UPDATE traitement SET  numR=?,reponse=?  WHERE idT=?";
        try {
            PreparedStatement pst = myDB.getInstance().getCon().prepareStatement(requete);

            pst.setInt(1, traitement.getNumR());
            pst.setString(2, traitement.getReponse());
            pst.setInt(3, traitement.getIdT());


            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("traitement with idT " + traitement.getIdT() + " updated successfully");
            } else {
                System.out.println("No traitement found with idT " + traitement.getIdT() + " for updating");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        }



    @Override
    public void deleteT(traitement traitement) throws SQLException {
        String requete = "DELETE FROM traitement WHERE idT=?";
        try {
            PreparedStatement pst = myDB.getInstance().getCon().prepareStatement(requete);
            pst.setInt(1, traitement.getIdT());
            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("traitement with idT " + traitement.getIdT() + " deleted successfully");
            } else {
                System.out.println("No traitement found with idT " + traitement.getIdT());
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    @Override
    public List<traitement> displayList() throws SQLException {
        List<traitement> tlist = new ArrayList<>();
        String requete = "SELECT * FROM traitement";
        try {
            Statement st = myDB.getInstance().getCon().createStatement();
            ResultSet res = st.executeQuery(requete);
            while (res.next()) {
                traitement t = new traitement();
                t.setIdT(res.getInt("idT"));
                System.out.println(t.getIdT());
                t.setNumR(res.getInt("numR")); // Use column name instead of index
                t.setReponse(res.getString("reponse"));
                tlist.add(t);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return tlist;
    }

}
